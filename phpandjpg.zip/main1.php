<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.dropbtn1 {
    background-color: #555;
    color: white;
    padding: 10px;
    font-size: 16px;
    border: none;
}

.dropdown1 {
    left:92%;
    top:1.2%;
    position: absolute;
    display: inline-block;
}

.dropdown1-content {
    display: none;
    position: absolute;
    background-color: #404040;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown1-content a {
    color: white;
    padding: 12px 24px;
    text-decoration: none;
    display: block;
}

.dropdown1-content a:hover {background-color: #FF0000;}

.dropdown1:hover .dropdown1-content {display: block;}

.dropdown1:hover .dropbtn1 {background-color: #FF0000;}
.container .btn {
    position: absolute;
    top: 4%;
    left: 80.5%;
    transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    background-color: #555;
    color: white;
    font-size: 16px;
    padding: 12px 24px;
    border: none;
    cursor: pointer;
    border-radius: 5px;
    text-align: center;
}

.container .btn:hover {
    background-color: black;
}
.container1 .btn {
    position: absolute;
    top: 4%;
    left: 88%;
    transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    background-color: #555;
    color: white;
    font-size: 16px;
    padding: 12px 24px;
    border: none;
    cursor: pointer;
    border-radius: 5px;
    text-align: center;
}

.container1 .btn:hover {
    background-color: black;
}
.container2 .btn {
    position: absolute;
    top: 4%;
    left: 95.2%;
    transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    background-color: #555;
    color: white;
    font-size: 16px;
    padding: 12px 24px;
    border: none;
    cursor: pointer;
    border-radius: 5px;
    text-align: center;
}

.container2 .btn:hover {
    background-color: black;
}
* {box-sizing: border-box;}
body {font-family: Verdana, sans-serif;}
.mySlides {display: none;}
img {vertical-align: middle;}

.container3 .btn {
    position: absolute;
    top: 4%;
    left: 72.2%;
    transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    background-color: #555;
    color: white;
    font-size: 16px;
    padding: 12px 24px;
    border: none;
    cursor: pointer;
    border-radius: 5px;
    text-align: center;
}

.container3 .btn:hover {
    background-color: black;
}
* {box-sizing: border-box;}
body {font-family: Verdana, sans-serif;}
.mySlides {display: none;}
img {vertical-align: middle;}


/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}
.container5 .content {
  position: absolute;
  bottom: 30%;
  background: rgb(0, 0, 0); /* Fallback color */
  background: rgba(0, 0, 0, 0.5); /* Black background with 0.5 opacity */
  color: #f1f1f1;
  width: 200%;
  height:40%;
  padding: 20px;
}
body, html {
    height: 100%;
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
}

.hero-image {
  background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url("giphy.gif" );
  height: 50%;
  width:50%;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
  left:25%;
  top:2%;
}

.hero-text {
  text-align: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
}

.hero-text button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 10px 25px;
  color: black;
  background-color: #ddd;
  text-align: center;
  cursor: pointer;
}

.hero-text button:hover {
  background-color: #555;
  color: white;
}
.dropbtn {
    background-color: #4CAF50;
    color: white;
    padding: 16px;
    font-size: 16px;
    border: none;
  
}

.dropdown {
    position: relative;
    display: inline-block;
left:45%;    
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #00ffff;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,1);
    z-index: 1;
}

.dropdown-content a {
    color: red;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
body {
    background-color: #fefbd8;
}



span {
    background-color: #f18973;
}
footer {
  opacity:0.6;
    background-color: #AAF0D1;
    padding: 10px;
    text-align: center;
    color: white;
}
.column {

  float: left;
  background-color:#f4a460;
  width: 17%;
  margin-bottom: 16px;
  padding: 0 8px;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.4);
}

.container {
  padding: 0 26px;
}


.title {
  color: red;
}

.button8 {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 10px;
  color: red;
  background-color: #00FFFF;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button8:hover {
  background-color: #555;
}

</style>
</head>
<body style="background-color:black;" >
<div class="container">
 <div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="logo.png" width=1550 height=500>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 3</div>
  <img src="111.jpg" width=1550 height=500>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 3</div>
  <img src="buddhu.png" width=1550 height=500>
</div>

</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
</div>

<script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 2000); // Change image every 2 seconds
}
</script>
  <button class="btn"><a href="#About Us"><font color ="white">About Us</font></button></a>
   
</div>
<div class="container1">
  
  <button class="btn"><a href="#contact"><font color="white">Contact</font></button></a>
   
</div>
<div class="dropdown1">
  <button class="dropbtn1">Login</button>
  <div class="dropdown1-content">
    <a href="acchalogin2.html">Admin Login</a>
    <a href="achhalogin.html">New Customers</a>
  </div>
</div>

<div class="container3">
  
  <button class="btn"><a href="mulbut.html"><font color ="white">Categories</font></button></a>
  
</div>
<div class="container5">

  <div class="content">
    <h1 ><b><i><font size="9" color="sandybrown">Description</font></i></b></h1>
    <p><i>Made to help the personal to decide the best suitable site for Online Shopping which is offering the best price for the product,keeping conscious of the fact to help a person spend his money Smartly.
      <br>Online Shopping as a Glorious invention it is can confuse the mind and and waste a huge amount of time.So for the  betterment of lifestyle we present you PEOPLE's CHOICE.</i></p>
  </div>
</div>

<div class="hero-image">
  <div class="hero-text">
    <h1 style="font-size:50px">Welcome to Peoples Choice</h1>
    <p>Search your Product here</p>
    <form action="query1.php" method="POST">
    
    <input type="text" name="search"  placeholder="Search for something.."/><br><br>

<button type="submit" name="s1">Search Here..</button>
</form>
<?php
$output='';
 print("$output");?>
<p id="demo"></p>

<script>
function myFunction() {
    var x = document.getElementById("mySearch").placeholder;
    document.getElementById("demo").innerHTML = x;
}
</script>
  </div>
</div>
<br>
<br>
<br>
<br>

<br>
<div class="row">
  <div class="column">
    <div class="card">
      <div class="container">
        <h2>UPDATE!</h2>
        <p class="title">New Feature Added</p>
        <p>Click Here for Search according to Range.</p>
        <p><button class="button8"><a href="range.html"><b><i> Search</i></b></button></p></a>
      </div>
    </div>
  </div>
<br><br>


<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<h1><font face="verdana" color="green"><pre>                                      Check The Prices Manually!</pre></font></h1>
<div class="dropdown">
  <button class="dropbtn">Check here</button>
  <div class="dropdown-content">
    <a href="https://www.flipkart.com/">Flipkart</a>
    <a href="https://www.amazon.in/">Amazon</a>
    <a href="https://www.snapdeal.com/">Snapdeal</a>
  </div>
</div>
 <br><br><br><br><br><br><br><footer>
  <p><a name="About Us"><h1><font size=6, color="black" > About Us</font></h1>
<font size=5, color="black"><pre>This is a project which is put forward and carried out by two Students of R.N. Shetty Institute Of Technology.
in the own words of the Creaters it is quoted as "Online Shopping Is really difficult task speciallyy for the young mind with the tons of options 
 provided to choose from so we need this kind of application to make it easier"  </pre>   
                                      </font></a></p><br><br>
                                    <p> <a name="contact"><h2><font size=6, color="black" >Contact</font></h2>    <pre> 
        <font size=5, color="black"> Name-Swapnil Sinha                     Vivek Mishra
    contact-8105381226                    9108007015
               Gmail-swapnil.somu98@gmail.com       vivek18498@gmail.com</font>
                                  </pre></a></p><br><br><br>
</footer>
</body>
</html> 
