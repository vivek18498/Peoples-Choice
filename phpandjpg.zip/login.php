
<!doctype html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body, html {
    height: 100%;
    font-family: Arial, Helvetica, sans-serif;
}

* {
    box-sizing: border-box;
}

.bg-img {
    /* The image used */
    background-image: url("logo.png");

    min-height: 380px;
    width:1550px;
    height:750px;

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    position: relative;
}

/* Add styles to the form container */
.container {
    position: absolute;
    right: 0;
    margin: 20px;
    max-width: 300px;
    padding: 16px;
    background-color: white;
}

/* Full-width input fields */
input[type=text], input[type=password] {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    border: none;
    background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
    background-color: #ddd;
    outline: none;
}

/* Set a style for the submit button */
.btn {
    background-color: #4CAF50;
    color: white;
    padding: 16px 20px;
    border: none;
    cursor: pointer;
    width: 100%;
    opacity: 0.9;
}

.btn:hover {
    opacity: 1;
}
.container1 .btn {
    position: absolute;
    top: 4%;
    left: 95%;
    width:8%;
    opacity:1%;
    transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    background-color: #555;
    color: red;
    font-size: 24px;
    padding: 12px 24px;
    border: none;
    cursor: pointer;
    border-radius: 5px;
    text-align: center;
}

.container1 .btn:hover {
    background-color: blue;
}
</style>
</head>
<body bgcolor="black">
   
<h2>Welcome to Admin Page</h2>
<div class="bg-img">
  <form action="add.php" class="container" method ="POST">
    <h1>Enter New Products Here...</h1>

    <label for="p_id"><b>p_id</b></label>
    <input type="text" placeholder="Enter p_id" name="p_id" required>

      <label for="p_name"><b>p_name</b></label>
    <input type="text" placeholder="Enter p_name" name="p_name" required>

      <label for="a_price"><b>a_price</b></label>
    <input type="text" placeholder="Enter actual price" name="a_price" required>

      <label for="d_price"><b>d_price</b></label>
    <input type="text" placeholder="Enter discount" name="d_price" required>

      <label for="di_price"><b>di_price</b></label>
    <input type="text" placeholder="Enter discounted price" name="di_price" required>

      <label for="s_id"><b>s_id</b></label>
    <input type="text" placeholder="Enter site id" name="s_id" required>


     <label for="category"><b>category</b></label>
    <input type="text" placeholder="Enter product categ" name="category" required>


    <button type="submit" class="btn">ADD</button>
  </form>
</div>
<div class="container1">
  
  <button class="btn"><a href="main1.php"><font color ="white">Home</font></button></a>

   
</div>

    </body>
    </html>
     <?php 
 
$host="localhost";
$user="root";
$password="";
$db="admin";
$com=mysqli_connect($host,$user,$password,"admin") or die("could not connect..");
 

 
if(isset($_POST['email'])){
    
    $uname=$_POST['email'];
    $password=$_POST['psw'];
    
    $query=mysqli_query($com,"select * from account where id='".$uname."'AND pass='".$password."' limit 1") or die("could not log in!");
 
   /* echo $count;*/
    if(mysqli_num_rows($query)==1){
  echo '<span style="color:#ff0000;text-align:center;">You Have Successfully Logged in</span>';
      /* echo "<center>Login Successfull..!! <br/>Redirecting you to ADMIN PAGE! </br>If not Goto <a href='acchalogin2.html'> Here </a></center>";
              echo "<meta http-equiv='refresh' content ='3; url=acchalogin2.html'>";*/
        exit();
    }
    else{
       /* echo '<span style="color:#ff0000;text-align:center;"> You Have Entered Incorrect Password</span>';*/
       echo "Username or Password Incorrect..";
        echo "<center>Redirecting you back to Login Page! If not Goto <a href='acchalogin2.html'> Here </a></center>";
              echo "<meta http-equiv='refresh' content ='0; url=acchalogin2.html'>";
        exit();
    }
        
}
?>