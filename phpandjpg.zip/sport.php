

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">  
    <meta name="description" content="">
    <meta name="author" content="templatemo">
    
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/templatemo-style.css" rel="stylesheet">
</head>
<body>
   <div class="bg">
  <div class="templatemo-content-container">
          <div class="templatemo-content-widget no-padding">
            <div class="panel panel-default table-responsive">
      <table class="table table-striped table-bordered templatemo-user-table">
                <thead>
                  <tr>            
                    <td><a class="white-text templatemo-sort-by">s_name </a></td>
                    <td><a  class="white-text templatemo-sort-by">p_name </a></td>
                  <td><a  class="white-text templatemo-sort-by">a_price</a></td>
                    <td><a  class="white-text templatemo-sort-by">d_price </a></td>
             <td><a  class="white-text templatemo-sort-by">di_price </a></td>
                  <!--     <td><a  class="white-text templatemo-sort-by">s_id</a></td>-->
  
          </thead>
         </tr>         



<?php
$com=mysqli_connect("localhost","root","","first") or die("couldnt connect");
/*$output1='';*/
if(isset($_POST['s6'])){
 
  $query=mysqli_query($com,"SELECT * from p_detail PD ,p_type PT,sites S where category='Sports'
    and PD.p_id=PT.p_id and PD.s_id=S.s_id ") or die("could not search!");
  
  $count=mysqli_num_rows($query);

  if($count==0){
    $output='there was no search results!';

  }
  else{
   
    while($row=mysqli_fetch_array($query)){
    /*
      $p_id=$row['p_id'];
      $p_name=$row['p_name'];
      $a_price=$row['a_price'];
      $d_price=$row['d_price'];
      $di_price=$row['di_price'];
      $s_id=$row['s_id'];
      $output .='<div>'.$p_id.' '.$p_name.'</div>';*/
      print"<tr>";
      echo '<td>' .$row['s_name'].'</td>';
      echo '<td>' .$row['p_name'].'</td>';
      echo '<td>' .$row['a_price'].'</td>';
      echo '<td>' .$row['d_price'].'</td>';
      echo '<td>' .$row['di_price'].'</td>';
    /*  echo '<td>' .$row['s_id'].'</td>';*/
      print "</tr>";

    }
  }
}
?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</body>
</html>