<?php

    $p_id=filter_input(INPUT_POST,'p_id');
    $p_name=filter_input(INPUT_POST,'p_name');
    $a_price=filter_input(INPUT_POST,'a_price');
    $d_price=filter_input(INPUT_POST,'d_price');
    $di_price=filter_input(INPUT_POST,'di_price');
    $s_id=filter_input(INPUT_POST,'s_id');
if(!empty($p_id) && !empty($p_name) && !empty($a_price) && !empty($d_price) && !empty($di_price) && ! empty($s_id)){

    $host='localhost';
    $dbusername="root";
    $dbpassword="";
    $dbname="first";
    //create connection
    $conn=new mysqli($host,$dbusername,$dbpassword,$dbname);
    if(mysqli_connect_error()){
        die('connect error('. mysqli_connect_errno().')'
            .mysqli_connect_error());
    }
    else{

        $sql="INSERT INTO p_detail(p_id,p_name,a_price,d_price,di_price,s_id)
        values('$p_id','$p_name','$a_price','$d_price','$di_price','$s_id')";
        if($conn->query($sql)){
            echo "new inserted";
        }
        else{
            echo "error:". $sql ."<br>".$conn->error;
        }
        $conn->close();
    }
    
}
else {
    echo "Username Should not be empty";
    die();
}
?>