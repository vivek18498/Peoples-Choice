

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">  
    <title>Manage Students</title>
    <meta name="description" content="">
    <meta name="author" content="templatemo">
    
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/templatemo-style.css" rel="stylesheet">
</head>
<body>
   <div class="bg">
  <div class="templatemo-content-container">
          <div class="templatemo-content-widget no-padding">
            <div class="panel panel-default table-responsive">
      <table class="table table-striped table-bordered templatemo-user-table">
                <thead>
                  <tr>            
                    <td><a class="white-text templatemo-sort-by">s_name</a></td>
                    <td><a  class="white-text templatemo-sort-by">p_name </a></td>
                    <td><a  class="white-text templatemo-sort-by">a_price</a></td>
                   <!--<td><a  class="white-text templatemo-sort-by">d_price </a></td>-->
             <td><a  class="white-text templatemo-sort-by">di_price </a></td>
                  <!--  <td><a  class="white-text templatemo-sort-by">s_id</a></td>-->
  
          </thead>
         </tr>         



<?php
$con=mysqli_connect("localhost","root","","first") or die("couldnt connect");
$output='';
if(isset($_POST['go'])){
  $range1 = $_POST['r1'];
    $range2 = $_POST['r2'];
  /*$searchq = preg_replace("#[^0-9a-z]#i","",$searchq);*/
  $query=mysqli_query($con,"SELECT S.s_name,PD.p_name,PD.a_price,PD.di_price from sites S,p_detail PD where 
  S.s_id = PD.s_id and
  PD.di_price between $range1 and $range2") or die("could not search!");
  
  $count=mysqli_num_rows($query);
  
  if($count==0){
    $output='there was no search results!';

  }
  else{
   
    while($row=mysqli_fetch_array($query)){
    /*
      $p_id=$row['p_id'];
      $p_name=$row['p_name'];
      $a_price=$row['a_price'];
      $d_price=$row['d_price'];
      $di_price=$row['di_price'];
      $s_id=$row['s_id'];
      $output .='<div>'.$p_id.' '.$p_name.'</div>';*/
      print"<tr>";
      echo '<td>' .$row['s_name'].'</td>';
      echo '<td>' .$row['p_name'].'</td>';
      echo '<td>' .$row['a_price'].'</td>';
      /*echo '<td>' .$row['d_price'].'</td>';*/
      echo '<td>' .$row['di_price'].'</td>';
     /* echo '<td>' .$row['s_id'].'</td>';*/
      print "</tr>";

    }
  }
}
?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</body>
</html>
