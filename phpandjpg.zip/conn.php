<?php
	$c_id=filter_input(INPUT_POST,'c_id');
	$c_name=filter_input(INPUT_POST,'c_name');
	$address=filter_input(INPUT_POST,'address');
	$gender=filter_input(INPUT_POST,'gender');
	$p_no=filter_input(INPUT_POST,'p_no');
	$p_name=filter_input(INPUT_POST,'p_name');
if(!empty($c_id) && !empty($c_name) && !empty($address) && !empty($gender) && !empty($p_no) && ! empty($p_name)){
	$host='localhost';
	$dbusername="root";
	$dbpassword="";
	$dbname="first";
	$conn=new mysqli($host,$dbusername,$dbpassword,$dbname);
	$trigger=mysqli_query($conn, "select c_date from login_trigger");
	$row=mysqli_fetch_array($trigger);
	if(mysqli_connect_error()){
		die('connect error('. mysqli_connect_errno().')'
			.mysqli_connect_error());
	}
	else{

		$sql="INSERT INTO customer(c_id,c_name,address,gender,p_no,p_name)
		values('$c_id','$c_name','$address','$gender','$p_no','$p_name')";
		if($conn->query($sql)){
			echo "new inserted at ";
			echo '<td>'.$row['c_date'].'</td>';
		}
		else{
			echo "error:". $sql ."<br>".$conn->error;
		}
		$conn->close();
	}
	
}
else {
	echo "Username Should not be empty";
	die();
}
?>